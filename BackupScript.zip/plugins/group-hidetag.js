let handler = async (m, { conn, text, participants }) => {
	const fkontak = {
		"key": {
			"participants": "0@s.whatsapp.net",
			"remoteJid": "status@broadcast",
			"fromMe": false,
			"id": "Halo"
		},
		"message": {
			"contactMessage": {
				"vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
			}
		},
		"participant": "0@s.whatsapp.net"
	}

	conn.sendMessage(m.chat, { text: text,
    contextInfo: {
                mentionedJid: participants.map(a => a.id),
                forwardingScore: 9999,
                isForwarded: true,
                externalAdReply: { 
                    showAdAttribution: true,
                    title: text,
                    body: " ",
                    mediaUrl: "https://wa.me/6282225850373",
                    description: " ",
                    previewType: "PHOTO",
                    thumbnail: fs.readFileSync(`./thumbnail2.jpg`),
             
                       sourceUrl: "https://wa.me/6282225850373",
                }
            }
},
  { quoted:  global.ftoko })
}

handler.help = ['hidetag']
handler.tags = ['group']
handler.command = /^(hidetag)$/i

handler.group = true
handler.admin = true

export default handler