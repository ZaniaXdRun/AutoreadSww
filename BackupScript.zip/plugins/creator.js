import fetch from 'node-fetch'
global.nomerown = '6282225850373'; // Masukkan nomor WhatsApp owner di sini
// Fungsi style untuk memformat teks
const style = (text, styleType = 1) => {
  const styles = [
    'jawa', // Style 1
    'jawar', // Style 2
    'jawaa', // Style 3
  ];
  let styleString = styles[styleType - 1] || styles[0]; // Default ke style 1
  let formattedText = text.split('').map(char => {
    const index = 'abcdefghijklmnopqrstuvwxyz0123456789'.indexOf(char.toLowerCase());
    return index !== -1 ? styleString.charAt(index) : char;
  }).join('');
  return formattedText;
};

let handler = async (m, { conn, usedPrefix, text, args, command }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
  let name = await conn.getName(who);

  // FAKE KONTAK
  const repPy = {
    key: {
      remoteJid: '0@s.whatsapp.net',
      fromMe: false,
      id: wm,
      participant: '0@s.whatsapp.net',
    },
    message: {
      requestPaymentMessage: {
        currencyCodeIso4217: "USD",
        amount1000: 999999999,
        requestFrom: '0@s.whatsapp.net',
        noteMessage: {
          extendedTextMessage: {
            text: 'QO BOTZ MD × DittzawTeam',
          },
        },
        expiryTimestamp: 999999999,
        amount: {
          value: 91929291929,
          offset: 1000,
          currencyCode: "INR",
        },
      },
    },
  };

  const vcard = `BEGIN:VCARD\nVERSION:3.0\nN:${await conn.getName('6282225850373@s.whatsapp.net')}\nFN:${await conn.getName('6282225850373@s.whatsapp.net')}\nitem1.TEL;waid=6282225850373:6282225850373\nitem1.X-ABLabel:WhatsApp\nitem2.EMAIL;type=INTERNET: zaniamasihpemula@yahoo.com\nitem2.X-ABLabel:Email\nitem3.URL:https://chat.whatsapp.com/JNhPP0OGxueIP5wfQnvW14\nitem3.X-ABLabel:Github\nitem4.ADR:;; Indonesia;;;;\nitem4.X-ABLabel:Region\nitem5.X-ABLabel:skill issue\nEND:VCARD`;

  const msg = await conn.sendMessage(m.chat, {
    contacts: {
      displayName: `zania dev botz Qo`,
      contacts: [{ vcard }],
    },
    contextInfo: {
      externalAdReply: {
        title: 'Owner Qo Botz MD',
        body: `dev bot zania xd `,
        thumbnail: await conn.resize('https://files.catbox.moe/evogy0.jpg', 300, 180),
        sourceUrl: `https://whatsapp.com/channel/0029VaefNUh8fewkWweWk535`,
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    },
  }, { quoted: repPy });

  await conn.reply(m.chat, `tuh kak ${name} nomor owner gw.`, msg);
};

handler.help = ['owner', 'creator'];
handler.tags = ['main'];
handler.command = /^(owner|creator)/i;
export default handler;