import fetch from 'node-fetch';
import FormData from 'form-data';
import { fileTypeFromBuffer } from 'file-type';

/**
 * By RayhanYgy
 * Upload image to a URL
 * Supported mimetypes:
 * - `image/jpeg`
 * - `image/jpg`
 * - `image/png`
 * - `video/mp4`
 * - `all files`
 * @param {Buffer} buffer Image Buffer
 * @returns {Promise<string>} URL hasil unggahan
 */
async function uploadImage(buffer) {
    const fileType = await fileTypeFromBuffer(buffer);
    const ext = fileType ? fileType.ext : 'unknown';
    const bodyForm = new FormData();
    bodyForm.append('file', buffer, `file.${ext}`);

    const res = await fetch('https://8030.us.kg/api/upload.php', {
        method: 'POST',
        body: bodyForm,
    });

    const data = await res.json();
    return data.result ? data.result.url : '';
}

let handler = async (m, { conn, text }) => {
    try {
        // Periksa apakah pesan memiliki file yang dikutip
        if (!m.quoted) {
            return conn.reply(m.chat, 'Silakan balas pesan dengan file untuk diunggah.', m);
        }

        // Unduh file dari pesan yang dikutip
        const buffer = await m.quoted.download();

        // Unggah file
        const url = await uploadImage(buffer);

        // Kirim URL hasil unggahan
        conn.reply(m.chat, `File berhasil diunggah: ${url}`, m);
    } catch (error) {
        console.error('Terjadi kesalahan:', error);
        conn.reply(m.chat, 'Terjadi kesalahan saat mengunggah file.', m);
    }
};

handler.help = handler.command = ['upload2', 'tourl'];
export default handler;