import axios from 'axios';
import cheerio from 'cheerio';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`harap masukkan username TikTok!\ncontoh: ${usedPrefix + command} username`);

  try {
    const result = await tiktokStalk(text);
    const metadata = JSON.parse(result);
//remake by https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
    if (metadata.userInfo) {
      const { username, nama, avatar, bio, verifikasi, totalfollowers, totalmengikuti, totaldisukai, totalvideo, totalteman } = metadata.userInfo;
      const responseMessage = `
*👤 Profil TikTok:*
- *Username:* ${username}
- *Nama:* ${nama}
- *Verifikasi:* ${verifikasi ? "Ya" : "Tidak"}
- *Bio:* ${bio || "Tidak ada bio"}
- *Total Pengikut:* ${totalfollowers.toLocaleString()}
- *Total Mengikuti:* ${totalmengikuti.toLocaleString()}
- *Total Disukai:* ${totaldisukai.toLocaleString()}
- *Total Video:* ${totalvideo.toLocaleString()}
- *Total Teman:* ${totalteman.toLocaleString()}


      `.trim();
     await conn.sendFile(m.chat, avatar, 'avatar.jpg', responseMessage, m);
      
    } else {
      m.reply('User tidak ditemukan.');
    }
  } catch (e) {
    m.reply(`Terjadi kesalahan: ${e.message}`);
  }
};

handler.help = ['tiktokstalk <username>'];
handler.tags = ['tools'];
handler.command =["tiktokstalk", "ttstalk", "infotiktok"];

export default handler;
async function tiktokStalk(username) {
  try {
    const response = await axios.get(`https://www.tiktok.com/@${username}?_t=ZS-8tHANz7ieoS&_r=1`);
    const html = response.data;
    const $ = cheerio.load(html);
    const scriptData = $('#__UNIVERSAL_DATA_FOR_REHYDRATION__').html();
    const parsedData = JSON.parse(scriptData);

    const userDetail = parsedData.__DEFAULT_SCOPE__?.['webapp.user-detail'];
    if (!userDetail) {
      throw new Error('User tidak ditemukan');
    }

    const userInfo = userDetail.userInfo?.user;
    const stats = userDetail.userInfo?.stats;

    const metadata = {
      userInfo: {
        id: userInfo?.id || null,
        username: userInfo?.uniqueId || null,
        nama: userInfo?.nickname || null,
        avatar: userInfo?.avatarLarger || null,
        bio: userInfo?.signature || null,
        verifikasi: userInfo?.verified || false,
        totalfollowers: stats?.followerCount || 0,
        totalmengikuti: stats?.followingCount || 0,
        totaldisukai: stats?.heart || 0,
        totalvideo: stats?.videoCount || 0,
        totalteman: stats?.friendCount || 0,
      }
    };

    return JSON.stringify(metadata, null, 2);
  } catch (error) {
    throw new Error(error.message);
  }
}