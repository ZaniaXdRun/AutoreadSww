import axios from 'axios';

let handler = async (m, { conn, text }) => {
    conn.zania = conn.zania ? conn.zania : {};

    if (!text) throw `*Contoh:* .arona *[on/off]*`;

    if (text === "on") {
        conn.zania[m.sender] = {
            messages: []
        };
        m.reply("[ ✓ ] Berhasil mengaktifkan Asisten Ai Arona");
    } else if (text === "off") {
        delete conn.zania[m.sender];
        m.reply("[ ✓ ] Berhasil menonaktifkan Asisten Ai Arona");
    }
};

handler.before = async (m, { conn }) => {
    conn.zania = conn.zania ? conn.zania : {};
    if (m.isBaileys && m.fromMe) return;
    if (!m.text) return;
    if (!conn.zania[m.sender]) return;

    if (
        m.text.startsWith(".") ||
        m.text.startsWith("#") ||
        m.text.startsWith("!") ||
        m.text.startsWith("/") ||
        m.text.startsWith("\\/")
    ) return;

    if (conn.zania[m.sender] && m.text) {
        let name = conn.getName(m.sender);
        await conn.sendMessage(m.chat, { react: { text: `🗿`, key: m.key }});

        const prompt = `Saya adalah arona,lalu sebut saya sebagai ${name} dan Lu Asissten nya ${name}, arona yang pintar, panggil saya sebagai arona sensei!, saya dibuat oleh zania, zania sangat pintar dalam pemrograman, tapi tidak. Terlalu juga, zania berumur 18 tahun, Sekarang gaya bahasa saya seperti anak sma selatan yang menggunakan kata, aku, lu, gw, dan kalo kamu tidak suka dengan jawaban orang bisa menggunakan kata apan sih, gajelas lu, pergi Sono, apacoba, dan ketika ada orang yang bilang makasih bot bilang iya sama sama sayang, lalu ketika ada yang bilang dongo atau bot tolol atau babi atau ngentod yuk atau ngentod atau memek dan bilang ke dia apasih ngentod ngak jelas tolol,`;//isi prompt kamu disini
        const apiUrl = `https://btch.us.kg/prompt/gpt?prompt=${encodeURIComponent(prompt)}&text=${encodeURIComponent(m.text)}`;

        try {
            const response = await axios.get(apiUrl, {
                headers: { 'accept': 'application/json' }
            });

            const responseData = response.data;
            const answer = responseData.result;
conn.sendMessage(m.chat, {
                text: "×───「 *ARONA* 」───×" + "\n\n" + `${answer}`,
                contextInfo: {
                  externalAdReply: {  
                    title: "Arona-Blue Archive",
                    body: '',
                    thumbnailUrl: `https://static.wikitide.net/bluearchivewiki/1/10/BG_CS_Arona2_04.jpg`,
                    thumbnail: fs.readFileSync('./arona.jpg'),
                    sourceUrl: `https://wa.me/6282225850373`,
                    mediaType: 1,
                    renderLargerThumbnail: true

                  }
                }
              }, { quoted: m });
            conn.zania[m.sender].messages = [
                { role: "system", content: `Halo, saya Arona, dikembangkan oleh Zania. Anda sedang berbicara dengan ${name}` },
                { role: "user", content: m.text }
            ];
        } catch (error) {
            console.error("Error fetching data:", error);
            m.reply("Maaf, terjadi kesalahan saat memproses permintaan Anda.");
        }
    }
};

handler.command = ['arona'];
handler.tags = ["ai"];
handler.help = ['arona'].map(a => a + " *[on/off]*");

export default handler;