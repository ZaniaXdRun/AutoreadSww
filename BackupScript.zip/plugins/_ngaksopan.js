import util from "util";
import path from "path";

let handler = async (m, { conn }) => {
let audio = './maa.mp3'
await conn.sendFile(m.chat, audio, 'error.mp3', null, fkontak, true, {
type: 'audioMessage', 
ptt: false, seconds: 0,contextInfo: {
         externalAdReply: { showAdAttribution: true,
 mediaUrl: 'www.isekaiwebgo.my.id/',
    mediaType: 2, 
    description: 'www.isekaiwebgo.my.id/',
    title: "Yang bener aja lu",
    body: "Jangan sange ya",
    thumbnail: await (await fetch('https://telegra.ph/file/954afe562e58c144620ae.png')).buffer(),
    sourceUrl: 'www.instagram.com/isekaigoweb.my.id'
}
     }
    })
}
handler.customPrefix = /^(pap mmk|pap memek|pap ktol|pap kontol|gimage bokep|gimage hentai|image hentai|image bokep|gimage cewe telanjang.|gimage bokep|gimage hentai|.image hentai|.image bokep|.gimage cewe telanjang|.gimage anime hentai|.image anime hentai|.pin bokep|pin hentai|.pinterest hentai|.pinterest bokep|.pin cewe telanjang|.pin bokep|.pin hentai|.pinterest hentai|.pinterest bokep|.pin cewe telanjang|.pin anime hentai|.pinterest anime hentai|.pin tobrut|.pin cewe bohay|.pin ngewe|.pinterest ngewe|.pin ngentod|.pinterest ngewe|.pin cewe tobrut|.pinterest cewe tobrut|.pin cewe seksi|.pinterest cewe seksi|.pin cewe tanpa baju|.pinterest cewe tanpa baju|.pin nsfw loli|.pinterest nsfw loli|.pin nsfw hoshino|.pinterest nsfw hoshino|.pin konbrut|.pinterest konbrut|.pin nsfw anime|.pinterest nsfw anime|.pin nsfw|.pinterest nsfw|.pixiv hentai|.pixiv tobrut|.pixiv konbrut|.pixiv kontol|.pixiv kntol.pixiv ktol|.pixiv ktl|.pixiv telanjang|.pixiv cewe telanjang|.pixiv loli hentai|.pixiv crot|.pixiv cewe tanpa baju|.pixiv cewe tanpa busana|.pixiv memek|.pixiv memeg|.pixiv mmk|.pixiv ngewe|.pixiv ewe|.pixiv ngentod|.pixiv seks|.pixiv sexs|.pixiv cewe bikin sange|.pixiv xxx|.pixiv hentai anime|.pixiv loli hot|.pixiv loli hentai hot|.pixiv hot hentai|.pixiv hot loli crot|.pixiv sperma|.pixiv ambatukam|.pixiv ambalabu|.pixiv cewe tobrut|.pixiv ciwi tobrut|.pixiv kontol panjang|.pixiv silit|.pixiv bokong|.pin nude|.pixiv loli nude|.pin loli nude|.pixiv nude|.pixiv ah ah crot)$/i
handler.command = new RegExp();

export default handler;