let handler = async (m, { conn, text, usedPrefix, command }) => {
    let time = text
    if(!text) return m.reply("Example: \n- .delschedule all\n- .delschedule 12:00:00")
    if (!global.schedules) global.schedules = {};
        if (!global.schedules[m.chat]) {
        m.reply(`Tak ada schedule yg aktif di grup ini!`);
        return;
    }

    if (time === "all") {
        delete global.schedules[m.chat];
        m.reply(`Berhasil! Semua schedule aktif di group ini telah dihapus!.`);
    } else {
        const newTimes = global.schedules[m.chat].times.filter(entry => entry.time !== time);
        if (newTimes.length === global.schedules[m.chat].times.length) {
            m.reply(`Tak ada schedule untuk waktu ${time} di group ini`);
        } else {
            global.schedules[m.chat].times = newTimes;
            if (global.schedules[m.chat].times.length === 0) {
                delete global.schedules[m.chat];
                m.reply(`Tak ada schedule time ${time} di group ini telah dihapus! Tidak ada lagi schedule yang tersisa.`);
            } else {
                m.reply(`Tak ada schedule time ${time} di group ini sudah dihapus!.`);
            }
        }
    }
    }
handler.help = ['delschedule 12:00:00 atau all'];
handler.tags = ['group', 'adminry'];
handler.command = /^(delschedule)$/i;

handler.admin = true;
handler.botAdmin = true;

export default handler;