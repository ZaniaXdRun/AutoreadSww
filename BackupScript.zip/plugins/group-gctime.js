let handler = async function handler(m, { conn, args, usedPrefix, command }) {
    if (!global.grouptime) {
        global.grouptime = {};
    }
    if (!global.grouptimeStatus) {
        global.grouptimeStatus = {};
    }

    let chatId = m.chat;

    if (args[0] === 'reset') {
        global.grouptime[chatId] = 0; // Reset grouptime untuk grup ini
        global.grouptimeStatus[chatId] = null; // Reset status untuk grup ini
        return m.reply('Sukses, timer grup telah di-reset.');
    }

    if (args[0] === 'status') {
        if (global.grouptime[chatId] && global.grouptime[chatId] > Date.now()) {
            let remainingTime = global.grouptime[chatId] - Date.now();
            let minutes = Math.floor((remainingTime / 1000) / 60);
            let seconds = Math.floor((remainingTime / 1000) % 60);
            return m.reply(`Grup akan ${global.grouptimeStatus[chatId] === 'announcement' ? 'ditutup' : 'dibuka'} dalam ${minutes} menit ${seconds} detik.`);
        } else {
            return m.reply('Grup saat ini tidak memiliki pengatur waktu yang aktif.');
        }
    }

    let isClose = {
        open: 'not_announcement',
        close: 'announcement',
    }[(args[0] || '').toLowerCase()];

    if (isClose === undefined) {
        return m.reply(`Penggunaan:\n- *${usedPrefix + command} open [waktu]*  >>  membuka grup dalam hitungan menit/jam.\n- *${usedPrefix + command} close [waktu]*  >>  menutup grup dalam hitungan menit/jam.\n- *${usedPrefix + command} reset*  >>  menyetel ulang pengatur waktu.\n- *${usedPrefix + command} status*  >>  melihat waktu sisa hingga penutupan grup.`);
    }

    // Parse waktu dari argumen
    let time = parseInt(args[1]);

    if (isNaN(time)) {
        return m.reply(`*Tambahkan waktu menit/jam.* Contoh:\n- *${usedPrefix + command} open 1menit*\n- *${usedPrefix + command} close 1jam*\n- *${usedPrefix + command} reset*\n- *${usedPrefix + command} status*`);
    }

    // Mengonversi waktu menjadi milidetik
    let delay = 0;
    if (args[1].match(/^[0-9]+jam$/i)) {
        delay = time * 60 * 60 * 1000; // Jam ke milidetik
    } else if (args[1].match(/^[0-9]+menit$/i)) {
        delay = time * 60 * 1000; // Menit ke milidetik
    } else {
        return m.reply(`*Format waktu tidak valid.* Contoh:\n- *${usedPrefix + command} open 1menit*\n- *${usedPrefix + command} close 1jam*\n- *${usedPrefix + command} reset*\n- *${usedPrefix + command} status*`);
    }

    if (isClose === 'announcement') {
        m.reply(`Grup ini akan ditutup dalam waktu ${args[1]}.`);
        global.grouptime[chatId] = Date.now() + delay; // Set grouptime untuk grup ini
        global.grouptimeStatus[chatId] = 'announcement';
        setTimeout(async () => {
            if (Date.now() >= global.grouptime[chatId]) { // Cek grouptime untuk grup ini
                await conn.groupSettingUpdate(chatId, isClose);
                m.reply('Sukses, grup ini telah ditutup dan semua member tidak dapat mengirim pesan untuk sementara.');
            }
        }, delay);
    } else {
        m.reply(`Grup ini akan dibuka dalam waktu ${args[1]}.`);
        global.grouptime[chatId] = Date.now() + delay; // Set grouptime untuk grup ini
        global.grouptimeStatus[chatId] = 'not_announcement';
        setTimeout(async () => {
            if (Date.now() >= global.grouptime[chatId]) { // Cek grouptime untuk grup ini
                await conn.groupSettingUpdate(chatId, isClose);
                m.reply('Sukses, grup ini telah dibuka dan semua member dapat mengirim pesan.');
            }
        }, delay);
    }
};

handler.help = ['grouptime'];
handler.tags = ['group'];
handler.command = ['grouptime', 'gctime'];
handler.group = true;
handler.botAdmin = true;
handler.admin = true;
export default handler;