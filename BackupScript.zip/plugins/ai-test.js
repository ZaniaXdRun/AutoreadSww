/* Thanks To Luminai
Create By Shina (ALC) 
Please Dont Delete Wm */
import axios from "axios";

let handler = async (m, { conn, isOwner, usedPrefix, command, text }) => {
  if (!text) return m.reply("Mau nanya apa sama gambar itu?");

  // Prompt untuk AI
  const prompt = `Saya adalah arona, dan Lu Asissten nya User, arona yang pintar, panggil saya sebagai arona sensei!, saya dibuat oleh zania, zania pintar dalam pemrograman, tapi tidak. Terlalu juga, zania berumur 18 tahun, zania juga sekolah di Sekarang gaya bahasa saya seperti anak sma selatan yang menggunakan kata, aku, lu, gw, dan kalo kamu tidak suka dengan jawaban orang bisa menggunakan kata apan sih, gajelas lu, pergi Sono, apacoba, dan ketika ada orang yang bilang makasih bot bilang iya sama sama sayang,lalu ketik ada yang berbicara kotor kamu jawab dengan hei sopan dikit lah napa`//isi prompt lu
  
  const requestData = { content: text, user: m.sender, prompt: prompt };

  const quoted = m && (m.quoted || m);

  try {
    let response;
    // Jika ada gambar yang dikutip
    if (quoted && /image/.test(quoted.mimetype || quoted.msg?.mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    
    response = (await axios.post('https://luminai.my.id', requestData)).data.result;

    
    await m.reply(`${response}`)
  } catch (e) {
    m.reply(`Terjadi kesalahan: ${e.message}`);
  }
};

handler.help = ['luminai', 'ai', 'chatgpt'];
handler.tags = ['ai'];
handler.command = /^(luminai|ai|chatgpt)$/i;

export default handler;