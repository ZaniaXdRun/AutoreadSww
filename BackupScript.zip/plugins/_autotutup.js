import moment from 'moment-timezone';
import schedule from 'node-schedule';

const timeZone = 'Asia/Jakarta';

// Konfigurasi waktu tutup dan buka grup
const closeTime = '22:00';
const openTime = '05:10';

// Daftar ID grup yang ingin dikelola
const groupChats = [
    '120363140499070786@g.us',
    '120363223334828182@g.us'
];

// Variabel status grup dan nama asli grup
let groupStatus = {};
let originalGroupNames = {};
let reminderSent = {};

// Fungsi untuk memeriksa waktu dan mengubah status serta nama grup
const checkGroupsStatus = async (conn) => {
    const currentTime = moment().tz(timeZone).format('HH:mm');

    for (const chatId of groupChats) {
        const groupMetadata = await conn.groupMetadata(chatId);
        const currentGroupName = groupMetadata.subject;

        // Simpan nama asli grup jika belum tersimpan
        if (!originalGroupNames[chatId]) {
            originalGroupNames[chatId] = currentGroupName;
        }

        // Hitung waktu 5 menit sebelum tutup dan buka
        const closeReminderTime = moment(closeTime, 'HH:mm').subtract(5, 'minutes').format('HH:mm');
        const openReminderTime = moment(openTime, 'HH:mm').subtract(5, 'minutes').format('HH:mm');

        // Pengingat 5 menit sebelum tutup
        if (currentTime === closeReminderTime && !reminderSent[`${chatId}-close`]) {
            await conn.sendMessage(chatId, { text: `Halo Para Member!!
<-> ɢʀᴏᴜᴘ ᴀᴋᴀɴ ᴛᴇʀᴛᴜᴛᴜᴘ 5 ᴍᴇɴɪᴛ ʟᴀɢɪ <->` });
            reminderSent[`${chatId}-close`] = true; // Setel pengingat terkirim
        }

        // Pengingat 5 menit sebelum buka
        if (currentTime === openReminderTime && !reminderSent[`${chatId}-open`]) {
            await conn.sendMessage(chatId, { text: `Halo Para member!!
<-> ɢʀᴏᴜᴘ ᴀᴋᴀɴ ᴛᴇʀʙᴜᴋᴀ 5 ᴍᴇɴɪᴛ ʟᴀɢɪ <->` });
            reminderSent[`${chatId}-open`] = true; // Setel pengingat terkirim
        }

        // Tutup grup jika waktunya tepat dan grup belum ditutup
        if (currentTime === closeTime && groupStatus[chatId] !== 'closed') {
            await conn.groupSettingUpdate(chatId, 'announcement');
            //await conn.groupUpdateSubject(chatId, `${originalGroupNames[chatId]} (TIDUR)`);
            await conn.sendMessage(chatId, { text: `( Selamat Malam Semua ^_^ )\nJangan lupa tidur yah kalo ngak tidur nanti sakit loh •_•`});
            groupStatus[chatId] = 'closed';
            reminderSent[`${chatId}-close`] = false; // Reset pengingat
        }

        // Buka grup jika waktunya tepat dan grup belum dibuka
        if (currentTime === openTime && groupStatus[chatId] !== 'opened') {
            await conn.groupSettingUpdate(chatId, 'not_announcement');
            // await conn.groupUpdateSubject(chatId, originalGroupNames[chatId]); // Kembalikan nama asli grup
            await conn.sendMessage(chatId, { text: `( Ohayo Minna San💫 )\nGroup Telah di buka dan semua member bisa chat kembali` });
            groupStatus[chatId] = 'opened';
            reminderSent[`${chatId}-open`] = false; // Reset pengingat
        }
    }
};

// Jadwalkan pemeriksaan status grup setiap menit
schedule.scheduleJob('* * * * *', () => {
    checkGroupsStatus(conn);
});