import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    
const res = await fetch('https://api.callmebot.com/whatsapp.php?phone=6282225850373&text=This+is+a+test&apikey=7770928', {
        method: 'POST',
        body: " ",
    });
m.reply("404")

}
handler.help = ['ptest']
handler.tags = ['owner']
handler.command = /^(ptest)/i

handler.owner = true

handler.fail = null

export default handler