import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, command, text, args }) => {
  if (!args[0]) throw `*Select Tag:*
blowjob
neko
trap
waifu`
  let res = await fetch(`https://api.waifu.pics/nsfw/${text}`)
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if (!json.url) throw 'Error!'
  conn.sendButton(m.chat, `Search: ${args[0]}`, global.wm, json.url, [['NEXT', `.animensfw ${args[0]}`]], m)
}
handler.command = /^(hentaiimg)$/i
handler.tag = ['nsfw']
handler.help = ['hentaiimg']

handler.premium = true

export default handler